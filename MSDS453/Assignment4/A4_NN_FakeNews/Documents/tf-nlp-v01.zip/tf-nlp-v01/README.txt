Text Classification with Neural Networks

This directory illustrates neural network modeling best practices in supervised learning. 

We use the Reduced Reuters Corpus, as documented in the directory reuters-corpus-v001.

We borrow code from a simple image classification problem, illustrated by code in the directory tf-gpu-mnist-v5.

And we utilize tokenization and word embedding vectorization methods from the Keras API to TensorFlow. That is, we make a special attempt to stay within the TensorFlow environment.  

When we talk about neural network modeling best practices, we mean practices such as these:

(1) Tripartite splitting of the corpus into training, validation (development/dev), and hold-out test sets, 

(2) Employ early stopping (that is, we stop the training process based on well-defined performance criteria, rather stopping training at a fixed number of epochs),

(3) Evaluate modeling methods across various meaningful metrics on hold-out test sets, where meaningful metrics might include the area under the ROC curve for binary classification, F1 for multinomial classification, and various specialized metrics appropriate for natural language processing tasks, and

(4) Examine the effects of alternative hyperparameter settings as appropriate for natural language processing tasks,

(5) Provide summaries of model stucture (number and types of layers, nodes/items within layers, and activation functions), as well as the number of parameters being estimated,

(6) Utilize visualization best practices in displaying information about the model building process, such as accuracy and loss plots for training and validation (development/dev) sets across epochs of the training process.


A variety of neural network structures may be implemented with TensorFlow/Keras:
Dense, RNN, LSTM, Bidirectional LSTM, GRU, and 1D CNN. We use a 1D CNN in this code.

Hyperparameter settings such as the following might be set in advance:
vocab_size = 10000  # number of unique words to use in tokenization
embedding_dim = 16  # dimension of neural network embedding for a word
max_length = 120    # number of words to be retained in each document

The program creates four output files:
fig-training-process.pdf shows training and dev accuracy and loss
fig-confusion-matrix.pdf shows the confusion matrix for the hold-out test set
file_embeddings_out.tsv shows the fitted word embeddings
file_words_out.tsv shows words in the vocabulary

The last two of these files may be loaded into the TensorFlow visualization tool at
http://projector.tensorflow.org/

A listing of the console output was obtained by piping to listing-tf-nlp.txt