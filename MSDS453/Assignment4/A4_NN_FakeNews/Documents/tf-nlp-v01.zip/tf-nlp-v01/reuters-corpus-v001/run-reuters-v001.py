# Reuters corpus work (2019-02-09)

# Program by Thomas W. Miller

# The initial Reuters corpus has 10,788 documents from the Reuters financial
# newswire service, partitioned into a training set with 7769 documents
# and a test set with 3019 documents.  The total size of the corpus is
# about 43 MB.  It is also available for download from
# http://kdd.ics.uci.edu/databases/reuters21578/reuters21578.html 
# which includes a more extensive history of the data revisions.
# The corpus may be used for various language tasks. A common task is text classification.

# This program imports the initial Reuters corpus and converts it into two
# JSON lines files for subsequent text analytics and natural language 
# processing. The first order of business was to ensure that each document
# was associated with one and only one news category.
# The second order of business was to ensure that there was
# a sufficient number of documents (defined as MINDOCS in the program)
# to be used as training data.

# Reuters is on of many NLTK corpora: http://www.nltk.org/nltk_data/

# Here is the description of the Reuters corpus:
# The Reuters-21578 benchmark corpus, ApteMod version [ download | source ]
# id: reuters; size: 6378691; author: ; copyright: ; license: The copyright for 
# the text of newswire articles and Reuters annotations in the Reuters-21578 
# collection resides with Reuters Ltd. Reuters Ltd. and Carnegie Group, Inc. 
# have agreed to allow the free distribution of this data for research purposes only. 
# If you publish results based on this data set, please acknowledge its use, refer 
# to the data set by the name 'Reuters-21578, Distribution 1.0', and inform your 
# readers of the current location of the data set.

# Additional information about the Reuters corpus is provided at 
# http://kdd.ics.uci.edu/databases/reuters21578/README.txt
# which we have included in the zip arcive of corpus files

# Note information on NLTK corpus readers at 
# http://www.nltk.org/howto/corpus.html 
# Make sure nltk and reuters corpus have been installed in the Python environmanet
# pop install nltk
# python -m nltk.downloader reuters

from nltk.corpus import reuters
import numpy as np
import pandas as pd
import json

# Set cutoff for the minimum number of documents per category
# This affects the size of the resulting reuters corpora
# MINDOCS = 40  # gives 15 valid category names
# MINDOCS = 71  # gives 10 valid category names
MINDOCS = 100  # gives 8 valid category names, 5583 train, 2208 test documents

# Some sample functions for the Reuters corpus are shown in 
# https://www.programcreek.com/python/example/104628/nltk.corpus.reuters.fileids
# For example, here is a function for identifying the categories of documents:
def categories(fileids):
    """
    Returns all categories for fileids
    """
    return reuters.categories(fileids) 


print('Number of categories: ', len(reuters.categories()), '\n')

print('Category names: ')
print(reuters.categories())

documents = reuters.fileids()
print(str(len(documents)) + " documents")

initial_train_docs = list(filter(lambda doc: doc.startswith("train"), documents))
print('\n', str(len(initial_train_docs)) + " initial training documents")

print('File names of the first five train documents', initial_train_docs[:5])

initial_test_docs = list(filter(lambda doc: doc.startswith("test"), documents))
print('\n', str(len(initial_test_docs)) + " initial test documents")

print('File names of the first five test documents', initial_test_docs[:5])

# Review of the original Reuters data shows that some documents
# are associated with more than one category. This complicates 
# the text classification task. So let's retain only those
# documents associated with one and only one category.
train_docs = []
test_docs = []

for train_name in initial_train_docs:
	if len(categories(train_name)) == 1:
		train_docs.append(train_name)
print('\n', str(len(train_docs)) + " train documents associated with one category only")	

for test_name in initial_test_docs:
	if len(categories(test_name)) == 1:
		test_docs.append(test_name)
print('\n', str(len(test_docs)) + " test documents associated with one category only")

# Define lists of categories associated with the final train_docs and test_docs
train_categorys = []
test_categorys = []

for train_name in train_docs:
	train_categorys.append(categories(train_name)) 

# Determine the number of documents associated with each category
vals, counts = np.unique(train_categorys, return_counts=True)
train_df = pd.DataFrame({'vals':vals,'counts':counts})
print('\nTrain documents per category:')
print(train_df)

for test_name in test_docs:
	test_categorys.append(categories(test_name))	

vals, counts = np.unique(test_categorys, return_counts=True)
test_df = pd.DataFrame({'vals':vals,'counts':counts})
print('\nTest documents per category:')
print(test_df)

# Identify the categories that have at least MINDOCS train documents
print('\nTrain documents per valid category')

valid_train = train_df[train_df['counts'] >= MINDOCS]

# valid_train = train_df.query("counts > 50")
print(valid_train)
print('\n', valid_train['counts'].sum(), 'valid train documents')

valid_categories = list(valid_train['vals'])
print('\nList of', len(valid_categories), 
	'valid category names:\n', valid_categories)

valid_test = test_df[test_df['vals'].isin(valid_categories)]
print('\nCorresponding test documents per valid category')
print(valid_test)
print('\n', valid_test['counts'].sum(), 'valid test documents')

# Create reuters_train and reuters_test corpora 
# containing documents within the list of valid categories
reuters_train_file_name = []
reuters_train_category = []
reuters_train_text = []
for train_name in train_docs:
	if set(categories(train_name)).issubset(set(valid_categories)):
		reuters_train_file_name.append(train_name)
		reuters_train_category.append(categories(train_name))
		reuters_train_text.append(reuters.raw(train_name))

print('\n', str(len(reuters_train_file_name)) + " train documents count check")	
print('\n', str(len(reuters_train_category)) + " train labels count check")
print('\n', str(len(reuters_train_text)) + " train text count check")	

# create dictionary for reuters_train corpus for possible later use
reuters_train_dict = {'corpus':['reuters']*len(reuters_train_file_name),
                      'dataset':['train']*len(reuters_train_file_name),
                      'filename':reuters_train_file_name,
                      'category':reuters_train_category,
                      'text':reuters_train_text}
reuters_train_df = pd.DataFrame(reuters_train_dict)  # for possible later use

reuters_test_file_name = []
reuters_test_category = []
reuters_test_text = []
for test_name in test_docs:
	if set(categories(test_name)).issubset(set(valid_categories)):
		reuters_test_file_name.append(test_name)
		reuters_test_category.append(categories(test_name))
		reuters_test_text.append(reuters.raw(test_name))

print('\n', str(len(reuters_test_file_name)) + " test documents count check")	
print('\n', str(len(reuters_test_category)) + " test labels count check")	
print('\n', str(len(reuters_test_text)) + " test text count check")	

# create dictionary for reuters_test corpus for possible later use
reuters_test_dict = {'corpus':['reuters']*len(reuters_test_file_name),
                     'dataset':['test']*len(reuters_test_file_name),
                     'filename':reuters_test_file_name,
                     'category':reuters_test_category,
                     'text':reuters_test_text}
reuters_test_df = pd.DataFrame(reuters_test_dict)  # for possible later use

# export reuters_train corpus as JSON lines file
with open('reuters_train.jl', 'wt') as f:
    for item in range(len(reuters_train_file_name)):
        itemdict = {'corpus':'reuters',
                    'dataset':'train',
                    'filename':reuters_train_file_name[item],
                    'category':reuters_train_category[item][0],
                    'text':reuters_train_text[item]}
        f.write(json.dumps(itemdict))
        if item < len(reuters_train_file_name)-1:
        	f.write('\n')
print('\nReuters train data written to JSON lines file reuters_train.jl')

# export reuters_test corpus as JSON lines file
with open('reuters_test.jl', 'wt') as f:
    for item in range(len(reuters_test_file_name)):
        itemdict = {'corpus':'reuters',
                    'dataset':'test',
                    'filename':reuters_test_file_name[item],
                    'category':reuters_test_category[item][0],
                    'text':reuters_test_text[item]}
        f.write(json.dumps(itemdict))
        if item < len(reuters_test_file_name)-1:
        	f.write('\n')
print('\nReuters test data written to JSON lines file reuters_test.jl')
