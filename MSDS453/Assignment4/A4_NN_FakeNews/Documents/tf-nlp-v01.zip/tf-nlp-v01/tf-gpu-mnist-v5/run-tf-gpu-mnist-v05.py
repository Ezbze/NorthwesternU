# test TensorFlow/Keras on MNIST

# Developed by Thomas W. Miller
# Updated March 6, 2020

# example code run with TensorFlow 1.15.0 and Keras 2.2.4-tf.
# Executed on Windows 10 Pro Version 1809 OS build 17763.805, 
# along with Anaconda Conda version 4.7.1, Python version 3.7.5, 
# and pip version 19.3.1 for Python 3.7.5 A GPU system with CUDA 10.0.

# The numpy version for this test was 1.18.1
# It is possible to have two numpy versions installed on a system.
# This can cause problems. To ensure that a current version is
# installed, it may be necessary to unistall numpy twice 
# prior to installing a new version of numpy:
#     pip uninstall numpy
#     pip uninstall numpy
#     pip install numpy

# To run under Windows PowerShell, place program code in a working
# directory, start up a Conda virtual environment with TensorFlow,
# and type:  python run-tf-gpu-mnist-vXX.py
# where XX is the version number for the code

# To run with output piped to a listing, type:
#   python run-tf-gpu-mnist-vXX.py > listing-tf-gpu-mnist.txt 
# where XX is the version number for the code

# The program should display results of the training process in
# the PowerShell console, while routing graphics to external pdf files.

# documentation relating to this example code may be found at:
# https://www.tensorflow.org/tutorials/keras/classification
# https://lambdalabs.com/blog/
# https://scikit-learn.org/stable/modules/generated/sklearn.metrics.f1_score.html
# https://seaborn.pydata.org/generated/seaborn.heatmap.html
# https://elitedatascience.com/python-seaborn-tutorial
# https://seaborn.pydata.org/tutorial/color_palettes.html
# https://machinelearningmastery.com/reproducible-results-neural-networks-keras/

# base modeling and model evaluation tools
import tensorflow as tf
from tensorflow import keras
from sklearn import metrics

# utility libraries for math and visualization
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import json

# utility for determining execution time
# most useful for the training process
from time import time 

# information about TensorFlow environment
print('\nNumpy version: ', np.__version__)
print('\nTensorFlow version: ', tf.__version__)
print('\nTensorFlow was built with CUDA: ', tf.test.is_built_with_cuda())
print('\nTensorFlow running with GPU: ', tf.test.is_gpu_available())

# with TensorFlow 2.0+, keras may be accessed as tf.keras
print('\nKeras version: ', tf.keras.__version__)

# TensorFlow eager execution is default in version 2.x.x
# but must be activated if version 1.x.x
if tf.__version__.split('.')[0] == '1':
    tf.enable_eager_execution()

# set random seed for reproducible results 
# this should work with CPU-only systems
# may not work with GPU-equiped systems
np.random.seed(seed = 9999)
# tf.random.set_seed(9999)

# set up base class for callbacks to monitor training
# and for early stopping during training
tf.keras.callbacks.Callback()

# try running a dense neural network with MNIST
print('\nWorking with MNIST:')
mnist = keras.datasets.mnist
(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

print('train_images.shape:', train_images.shape)
print('train_labels.shape:', train_labels.shape)

print('test_images.shape:', test_images.shape)
print('test_labels.shape:', test_labels.shape, '\n')

# plot the first 25 images to external file
plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(train_images[i], cmap=plt.cm.binary)
    plt.xlabel(train_labels[i])
# plt.show() # use if plot to screen is desired
plt.savefig('fig-example-train-images.pdf', 
    papertype = 'letter', orientation ='landscape')
plt.close()

# define a dense model with Keras
model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dense(10, activation='softmax')
])

# show the structure of the model, including number of parameters
print('Structure of Neural Network')
print(model.summary())

# define settings for training the model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# set model to run for epochs unless early stopping rule is met
# see documentation at https://keras.io/callbacks/
# note that 100 is many more epochs than needed for MNIST
# but we employ early stopping to shorten the training time
max_epochs = 100  
earlystop_callback = \
    tf.keras.callbacks.EarlyStopping(monitor='val_acc',\
    min_delta=0.01, patience=5, verbose=0, mode='auto',\
    baseline=None, restore_best_weights=False)

# show settings of hyperparameters and algorithms for training
print('\nSettings for Training')
print(json.dumps(model.get_config(), indent = 2, sort_keys = True))

# fit the model showing progress epoch-by-epoch
# define dev/validation set from within the training set 
# shuffle = False set to obtain reproducible results
# We also use time to compute execution time for training.
# What time is measured depends on the system (Windows versus other).
print('\nEpoch-by-Epoch Training Process')
begin_time = time()
history = model.fit(train_images, train_labels,
    epochs = max_epochs, shuffle = False,
    validation_split = 0.2, 
    verbose = 2,
    callbacks = [earlystop_callback])
execution_time = time() - begin_time
print('\nTime of execution for training (seconds):', \
	'{:10.3f}'.format(np.round(execution_time, decimals = 3)))

# evaluate fitted model on the full training set
train_loss, train_acc = model.evaluate(train_images,train_labels,verbose = 3)
print('\nFull training set accuracy:', \
	'{:6.4f}'.format(np.round(train_acc, decimals = 4)))

# evaluate the fitted model on the hold-out test set
test_loss, test_acc = model.evaluate(test_images,  test_labels, verbose = 3)
print('Hold-out test set accuracy:', \
	'{:6.4f}'.format(np.round(test_acc, decimals = 4)))

# The training process may be evaluated by comparing training and
# dev (validation) set performance. We use "dev" to indicate
# that these data are used in evaluating various hyperparameter
# settings. We do not test alternative hyperparameters here,
# but in other programs there will be much hyperparameter testing.
def plot_history(history):
    acc = history.history['acc']
    val_acc = history.history['val_acc']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    epoch_number = range(1, len(acc) + 1)
    plt.style.use('ggplot') # Grammar of Graphics plots
    plt.figure(figsize=(20, 10))
    plt.subplot(1, 2, 1)
    plt.plot(epoch_number, acc, 'b', label='Training')
    plt.plot(epoch_number, val_acc, 'r', label='Dev')
    plt.title('Training and Dev Set Accuracy')
    plt.xlabel('Epoch Number')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(epoch_number, loss, 'b', label='Training')
    plt.plot(epoch_number, val_loss, 'r', label='Dev')
    plt.title('Training and Dev Set Loss')
    plt.xlabel('Epoch Number')
    plt.ylabel('Loss')
    plt.legend()
    plt.savefig('fig-training-process.pdf', 
        papertype = 'letter', orientation ='landscape')
    plt.close()

# show training process in external visualizations
plot_history(history) 

# examine the predicted values within a precision/recall framework
test_preds = np.argmax(model.predict(test_images), axis = 1)

print('\n Listing of first twenty test labels and predictions')
print('test_labels', test_labels[:20])
print('test_preds ', test_preds[:20])

print("\nClassification report:\n%s"
      % (metrics.classification_report(test_labels, test_preds, \
	target_names = ['digit 0', 'digit 1', 'digit 2', 'digit 3', 'digit 4', \
	 'digit 5', 'digit 6', 'digit 7', 'digit 8', 'digit 9'])))

# note that the weighted average is most appropriate for classification
# problems that are unbalanced. See https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_recall_fscore_support.html#sklearn.metrics.precision_recall_fscore_support
print("Test set F1 (weighted average):", \
    metrics.precision_recall_fscore_support(test_labels, test_preds, average='weighted')[2], "\n")

cm_data = metrics.confusion_matrix(test_labels, test_preds)
print('Confusion matrix')
print('(rows = true digits, columns = predicted digits)\n%s' % cm_data)

# plot confusion matrix to external file
def plot_confusion(cm_data):
    plt.figure()
    selected_cmap = sns.cubehelix_palette(light=1, as_cmap=True)
    sns_plot = sns.heatmap(cm_data, annot=True, fmt="d", \
	    cmap = selected_cmap, linewidths = 0.5, cbar = False)
    sns_plot.set_yticklabels(sns_plot.get_yticklabels(), rotation = 0)
    plt.title('Confusion Matrix')
    plt.ylabel('True Digit')
    plt.xlabel('Predicted Digit')
    # plt.show() # use if plot to screen is desired
    plt.savefig('fig-confusion-matrix.pdf', 
        papertype = 'letter', orientation ='landscape')
    plt.close()

plot_confusion(cm_data)

print('\n NEURAL NETWORK MODELING COMPLETE\n')

# repeat information about TensorFlow environment
print('\nNumpy version: ', np.__version__)
print('\nTensorFlow version: ', tf.__version__)
print('\nTensorFlow was built with CUDA: ', tf.test.is_built_with_cuda())
print('\nTensorFlow running with GPU: ', tf.test.is_gpu_available())

# with TensorFlow 2.0+, keras may be accessed as tf.keras
print('\nKeras version: ', tf.keras.__version__)

